# FitStart — Health & Fitness Web App

This is a small, responsive Health & Fitness web application built with plain HTML, CSS, and JavaScript.

Features:
- Landing page with app introduction
- Three fitness plans (Beginner, Moderate, Advanced) with workouts and food plans
- Video Tutorials section with clickable thumbnails that open YouTube tutorials in a new tab
- Clean dashboard showing selected plan summary
- Mobile-first responsive design, easy to extend

How to run
1. Open `index.html` in a browser (double-click or right-click → Open with).
2. On a local dev server (recommended):

   - For a quick Python server (if you have Python installed):

     ```powershell
     # from project directory
     python -m http.server 8000
     # then open http://localhost:8000 in your browser
     ```

Design notes
- Colors use green, white, and light blue accents for a friendly fitness tone.
- Cards and hover effects make content approachable.
- Tutorials use YouTube thumbnails and open links in a new tab.

Next steps (optional)
- Add persistent user profiles and progress tracking
- Add a simple calorie calculator form
- Add animations or modal video player

Enjoy building and using the app!
